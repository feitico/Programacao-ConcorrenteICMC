#include "mpi.h"
#include <stdio.h>

/**
 * Programa exemplo para cria��o e defini��o de novos grupos de comunica��o
 */
int main( int argc, char * argv[  ] )

{
   int processId, i, flag = 0;
   int noProcessWorld, noProcessNew;
   /*
    * Lista dos processos a serem exclu�dos do novo comunicador gerado
	*/
   int processes[2] = {0,2};
  // int processes[1] = {0};
              
   /*
    * Vari�veis utilizadas para copia do grupo do comunicador global (MPI_COMM_WORLD) e defini��o do novo grupo
	*/
   MPI_Group  worldGroup, newGroup;

   /*
    * Novo comunicador com exclus�o do processo 0
    */
   MPI_Comm  newComm;

  
   /*
    * Inicia sess�o MPI
    */ 
   MPI_Init(&argc, &argv);

   /*
    * Obtem id dos processos em execu��o
    */
   MPI_Comm_rank(MPI_COMM_WORLD, &processId);

   /*
    * MPI_Comm_group(MPI_COMM_WORLD, &worldGroup)
    *
    * Realiza a copia do comunicador MPI_COMM_WORLD para a variavel worldGroup
    *
    * Par�metros:
    * MPI_COMM_WORLD: comunicador a ser copiado
    * worldGroup: variavel de destino
    */
   MPI_Comm_group(MPI_COMM_WORLD, &worldGroup);

   /*
    * MPI_Group_excl(worldGroup, 1, processes, &newGroup);
    *
    * Exclui processos de um determinado grupo enviando o resultado para um novo grupo
    *
    * Parametros:
    * worldGroup: grupo de processos do comunicador desejado
    * 1: numero de processos a serem excluidos
    * processes: lista de inteiros com os ids dos processos a serem excluidos
    * newGroup: novo grupo formado pela exclusao dos processos do grupo inicial
    */
   MPI_Group_excl(worldGroup, 2, processes, &newGroup);

/*  
 * MPI_Comm_create(MPI_COMM_WORLD, newGroup, &newComm);
 *
 * Cria o novo canal de comunicacao com os processos
 *
 * Parametros:
 * MPI_COMM_WORLD: Comunicador de origem
 * newGroup: grupo com os processos desejados
 * newComm: variavel que vai receber o novo comunicador
 */
   MPI_Comm_create(MPI_COMM_WORLD, newGroup, &newComm);
   
   /*
    * Obtem o tamanho do comunicador padrao
    */
 //  MPI_Comm_size(MPI_COMM_WORLD,&noProcessWorld);
 //  printf("Comunicador Padrao: %d\n" , noProcessWorld);

   /*
    * Obtem o tamanho do comunicador gerado
    * Erro pois comunicador 0 e 2 nao tem newComm
    */
//   MPI_Comm_size(newComm,&noProcessNew);
//   printf("Comunicador Gerado: %d\n", noProcessNew);


   fprintf(stderr, "Antes: processo: %d   Flag: %d\n", processId, flag); 

   /*
    * Caso id do processo seja igual a 1 muda o valor de flag para um e envia uma 
    * mensagem broadcast para o novo grupo de comunicacao (exclui processo 0)
    */
   if (processId == 1)
        flag = 1;  
   /*
    * Envio da mensagem broadcast para o novo grupo
    */
   
//   MPI_Bcast(&flag, 1, MPI_INT, 1, newComm);


   //Erro processo 2 nao tem newComm
   if (processId != 0)
      MPI_Bcast(&flag, 1, MPI_INT, 0, newComm);
//   MPI_Bcast(&flag, 1, MPI_INT, 1, MPI_COMM_WORLD);
    fprintf(stderr, "Depois  processo: %d   Flag: %d\n", processId, flag); 

    /*
   if (processId !=0){
      MPI_Comm_free(&newComm);
      MPI_Group_free(&newGroup);
   }
   */

   MPI_Finalize( );

   return 0;

}
