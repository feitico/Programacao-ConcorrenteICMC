#include "mpi.h"
#include <stdio.h>

int main(int argc, char **argv)
{
	int numtasks, rank, rc, dest, source, count, tag=1;
	char inmsg[10], outmsg[10]; 
	MPI_Status Stat;

	/*
	 * Inicia uma sessão MPI
	 */
	MPI_Init(&argc, &argv);
	/*
	 * Obtêm o id do processo
	 */
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	if (rank == 0) {
		dest = 1;
		outmsg[0] = 'x';
	       	outmsg[1] = 'i';
		outmsg[2] = 's';
		outmsg[3] = 'c';
		outmsg[4] = 'o';

		printf("Enviando a palavra %s para o procedimento %d\n", outmsg, dest);

		/*
		 * MPI_Send(&outmsg, 1, MPI_CHAR, dest, tag, MPI_COMM_WORLD)
		 * Envia informação de um processo para outro. Obrigatoriamente deve ter
		 * uma chamada MPI_Recv para receber os dados desta mensagem
		 *
		 * Parâmetros
		 * &outmsg: contém os dados da mensagem
		 * 1: número de itens a serem enviados. Neste caso 1.
		 * MPI_CHAR: Tipo de dados a ser enviado. Neste caso caractere
		 * dest: ID do processo de destino
		 * tag: usado para distinguir multiplas mensagens
		 * MPI_COMM_WORLD: Comunicador da mensagem.
		 */
		rc = MPI_Send(&outmsg, 6, MPI_CHAR, dest, tag, MPI_COMM_WORLD);
	}
	else if (rank == 1) {
		source = 0;

		/*
		 * MPI_Recv(&inmsg, 1, MPI_CHAR, source, tag, MPI_COMM_WORLD, &Stat);
		 * Recebe  informação de um processo. Obrigatoriamente deve ter
		 * uma chamada MPI_Send para receber os dados desta mensagem
		 *
		 * Parâmetros
		 * &inmsg: contém os dados da mensagem
		 * 1: número de itens a serem recebidos. Neste caso 1.
		 * MPI_CHAR: Tipo de dados a ser recebido. Neste caso caractere
		 * Source: Id do processo que enviou a mensagem
		 * tag: usada para destinguir multiplas mensagem
		 * MPI_COMM_WORLD: Comunicador da mensagem
		 * &Stat: Estrutura que contém informações sobre o tamanho da mensagem, fonte de destino e sua tag.
		 */
		
		rc = MPI_Recv(&inmsg, 6, MPI_CHAR, source, tag, MPI_COMM_WORLD, &Stat);
		printf("Recebi a mensagem %s, do procedimento %d\n", inmsg, source);
	}

	/*
	 * Finaliza a sessão MPI
	 */
	MPI_Finalize();
	return 0;
}

