#include "mpi.h"
#include <stdio.h>
#include <string.h>

/*
 * Exemplo 6 
 * Este programa que envia mensagem com caracteres de uma String para impressao em diferentes procedimentos
 * Problemas: O que ocorre quando o numero de procedimentos passado no programa principal ocorre?E quando é menor?
 * Por que isso ocorre? Como deve ser feito este tratamento?
 * MPI_Send e MPI_Receive são chamadas bloqueantes. Deve haver um tratamento para determinar como serão enviados estes caracteres e como 
 * irão ser tratados.
 */
int main(int argc, char **argv)
{
	int numtasks, rank, rc, dest, source, count, tag=1;
	char inmsg, outmsg[10]; 
	MPI_Status Stat;

	/*
	 * Inicia uma sessão MPI
	 */
	MPI_Init(&argc, &argv);
	/*
	 * Obtêm o id do processo
	 */
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	if (rank == 0) {
		outmsg[0] = 'x';
	       	outmsg[1] = 'i';
		outmsg[2] = 's';
		outmsg[3] = 'c';
		outmsg[4] = 'o';
		
		for(dest=1;dest<=strlen(outmsg);dest++){
			printf("Enviando o caracter %c para o procedimento %d\n", outmsg[dest-1], dest);

			/*
			 * MPI_Send(&outmsg, 1, MPI_CHAR, dest, tag, MPI_COMM_WORLD)
			 * Envia informação de um processo para outro. Obrigatoriamente deve ter
			 * uma chamada MPI_Recv para receber os dados desta mensagem
			 *
			 * Parâmetros
			 * &outmsg: contém os dados da mensagem
			 * 1: número de itens a serem enviados. Neste caso 1.
			 * MPI_CHAR: Tipo de dados a ser enviado. Neste caso caractere
			 * dest: ID do processo de destino
			 * tag: usado para distinguir multiplas mensagens
		 	 * MPI_COMM_WORLD: Comunicador da mensagem.
		 	 */
			rc = MPI_Send(&outmsg[dest-1], 1, MPI_CHAR, dest, tag, MPI_COMM_WORLD);
		}
	}
	else {
		source = 0;

		/*
		 * MPI_Recv(&inmsg, 1, MPI_CHAR, source, tag, MPI_COMM_WORLD, &Stat);
		 * Recebe  informação de um processo. Obrigatoriamente deve ter
		 * uma chamada MPI_Send para receber os dados desta mensagem
		 *
		 * Parâmetros
		 * &inmsg: contém os dados da mensagem
		 * 1: número de itens a serem recebidos. Neste caso 1.
		 * MPI_CHAR: Tipo de dados a ser recebido. Neste caso caractere
		 * Source: Id do processo que enviou a mensagem
		 * tag: usada para destinguir multiplas mensagem
		 * MPI_COMM_WORLD: Comunicador da mensagem
		 * &Stat: Estrutura que contém informações sobre o tamanho da mensagem, fonte de destino e sua tag.
		 */
		
		rc = MPI_Recv(&inmsg, 1, MPI_CHAR, source, tag, MPI_COMM_WORLD, &Stat);
		printf("Procedimento %d, recebeu o caracter %c, do procedimento %d\n",rank, inmsg, source);
	}

	/*
	 * Finaliza a sessão MPI
	 */
	MPI_Finalize();
	return 0;
}

