#include "mpi.h"
#include <stdio.h>

int main(int argc, char **argv)
{
	int rank, source = 0, dest = 0, rc;
	int value, totalValue;
	char inmsg, outmsg; 
	/*
	 * Inicializa a sessão MPI
	 */
	MPI_Init(&argc, &argv);

	/*
	 * Obtem ID do processo na variável rank
	 */
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	printf("Processo %d: %d\n", rank, value);
	
	
	/*
	 * Para processo de ID = 0 atribui value =  10
	 */
	if (rank == 0) 
		value = 10;
	 
	/*
	 * MPI_Bcast(&value, 1, MPI_INT, source, MPI_COMM_WORLD);
	 * 
	 * Envia mensagem para todos os processos pertencentes ao programa
	 *
	 * Parâmetros
	 * &value (IN): dado a ser enviado via broadcast
	 * 1 (IN): tamanho do dado a ser enviado
	 * MPI_INT (IN): tipo do dado a ser enviado
	 * source (IN): origem do dado a ser enviado
	 * MPI_COMM_WORLD (IN): conjunto dos procedimentos em execução
	 */
	MPI_Bcast(&value, 1, MPI_INT, source, MPI_COMM_WORLD);
	
	printf("Processo %d: %d\n", rank, value);

	value *= rank + 1;
	printf("Processo %d: %d\n", rank, value);

	/*
	 * MPI_Reduce(&value, &totalValue, 1, MPI_INT, MPI_SUM, dest, MPI_COMM_WORLD)
	 * 
	 * Realiza operacao de soma sobre a variavel &totalValue no processo 1
	 *
	 * Parâmetros
	 * &value (IN): dado a ser enviado via broadcast
	 * &totalValue (OUT): buffer que vai receber o dado
	 * 1 (IN): tamanho do dado a ser enviado
	 * MPI_INT (IN): tipo do dado a ser enviado
	 * MPI_SUM (IN): Operacao a ser realizada
	 * dest (IN): destino do dado a ser enviado
	 * MPI_COMM_WORLD (IN): conjunto dos procedimentos em execução
	 */
	
	MPI_Reduce(&value, &totalValue, 1, MPI_INT, MPI_SUM, dest, MPI_COMM_WORLD);
	
	if (rank == 0)
		printf("Valor final calculado: %d\n", totalValue);
	
	/*
	 * Finaliza a sessão MPI
	 */
	MPI_Finalize();
	return 0;
}

